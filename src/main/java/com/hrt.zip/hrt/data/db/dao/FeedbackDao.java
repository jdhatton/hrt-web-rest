package com.hrt.data.db.dao;

public interface FeedbackDao {

	public void addFeedback(long userId, String feedback);
	
}
