package com.hrt.data.db.beans;

public class Classroom {

	public Classroom() { }

}
