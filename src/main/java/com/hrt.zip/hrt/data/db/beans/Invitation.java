package com.hrt.data.db.beans;

public class Invitation {

	public Invitation() {
		// TODO Auto-generated constructor stub
	}

}
