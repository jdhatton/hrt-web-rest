package com.hrt.web.resources.client;

public class DataSyncResponse {

	private String response;

	
	
	public DataSyncResponse(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
	
}
