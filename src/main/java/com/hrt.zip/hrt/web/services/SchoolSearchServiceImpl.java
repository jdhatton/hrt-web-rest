package com.hrt.web.services;

import java.util.List;

import com.hrt.data.db.beans.District;
import com.hrt.data.db.beans.School;

public class SchoolSearchServiceImpl implements SchoolSearch {

	public SchoolSearchServiceImpl() {
		
	}

	public List<District> findSchoolDistricts(String zipCode) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<School> findSchoolsInDistrict(District schoolDistrict) {
		// TODO Auto-generated method stub
		return null;
	}

}
