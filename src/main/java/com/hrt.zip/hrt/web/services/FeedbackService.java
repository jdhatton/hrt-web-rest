package com.hrt.web.services;


public interface FeedbackService {

	public void processFeedback(long userId, String feedback);
}
