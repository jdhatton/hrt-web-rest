package com.hrt.web.services;

public abstract class DataService {

	public DataService() {
		//
		//
		//
	}

}
