package com.hrt.web.services;

public interface InvitationService {

}
